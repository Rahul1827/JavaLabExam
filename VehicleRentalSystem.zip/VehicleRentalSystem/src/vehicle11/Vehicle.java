package vehicle11;

public class Vehicle {

}
